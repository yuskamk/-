import { useState, useEffect } from 'react';

const AdvancedTodoApp = () => {
  // Все данные нашего приложения
  const [todos, setTodos] = useState([]); // Список задач
  const [inputValue, setInputValue] = useState(''); // Текст новой задачи
  const [filter, setFilter] = useState('all'); // Фильтр: все/активные/выполненные
  const [searchQuery, setSearchQuery] = useState(''); // Поисковый запрос
  const [language, setLanguage] = useState('ru'); // Язык: русский/английский

  // Тексты на разных языках
  const translations = {
    ru: {
      title: 'Менеджер задач',
      placeholder: 'Новая задача...',
      add: 'Добавить',
      all: 'Все',
      active: 'Активные',
      completed: 'Завершенные',
      search: 'Поиск...',
      delete: 'Удалить',
      emptyList: 'Список задач пуст'
    },
    en: {
      // Английские версии тех же текстов
    }
  };
  const t = translations[language];

  // Загружаем задачи из памяти браузера при запуске
  useEffect(() => {
    const savedTodos = localStorage.getItem('advancedTodos');
    if (savedTodos) {
      setTodos(JSON.parse(savedTodos));
    }
  }, []);

  // Сохраняем задачи в память браузера при их изменении
  useEffect(() => {
    localStorage.setItem('advancedTodos', JSON.stringify(todos));
  }, [todos]);

  // Добавляем новую задачу
  const addTodo = () => {
    if (inputValue.trim()) {
      const newTodo = {
        id: Date.now(), // Уникальный номер задачи
        text: inputValue,
        completed: false, // Не выполнена
        createdAt: new Date().toISOString(),
      };
      setTodos(prevTodos => [...prevTodos, newTodo]);
      setInputValue(''); // Очищаем поле ввода
    }
  };

  // Удаляем задачу
  const deleteTodo = (id) => {
    setTodos(prevTodos => prevTodos.filter(todo => todo.id !== id));
  };

  // Отмечаем задачу выполненной/невыполненной
  const toggleTodo = (id) => {
    setTodos(prevTodos =>
      prevTodos.map(todo =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  // Фильтруем и ищем задачи
  const filteredTodos = todos
    .filter(todo => {
      // Проверяем статус задачи
      const statusMatch =
        filter === 'all' ||
        (filter === 'active' && !todo.completed) ||
        (filter === 'completed' && todo.completed);
      
      // Проверяем поиск
      const searchMatch = todo.text.toLowerCase().includes(searchQuery.toLowerCase());
      
      return statusMatch && searchMatch;
    });

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <h1>{t.title}</h1>

      {/* Панель управления */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
        {/* Кнопка переключения языка */}
        <button onClick={() => setLanguage(lang => lang === 'ru' ? 'en' : 'ru')}>
          {language === 'ru' ? 'EN' : 'RU'}
        </button>
        
        {/* Поле поиска */}
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={t.search}
        />
      </div>

      {/* Форма добавления новой задачи */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && addTodo()}
          placeholder={t.placeholder}
          style={{ flexGrow: 1 }}
        />
        <button onClick={addTodo}>{t.add}</button>
      </div>

      {/* Кнопки фильтрации */}
      <div style={{ marginBottom: '10px' }}>
        {(['all', 'active', 'completed']).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{ 
              fontWeight: filter === f ? 'bold' : 'normal', 
              marginRight: '10px' 
            }}
          >
            {t[f]}
          </button>
        ))}
      </div>

      {/* Список задач */}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {filteredTodos.length === 0 ? (
          <li>{t.emptyList}</li>
        ) : (
          filteredTodos.map(todo => (
            <li
              key={todo.id}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '10px',
                border: '1px solid #ccc',
                marginBottom: '5px',
                // Зачеркиваем текст если задача выполнена
                textDecoration: todo.completed ? 'line-through' : 'none',
                opacity: todo.completed ? 0.6 : 1
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                {/* Чекбокс выполнения */}
                <input
                  type="checkbox"
                  checked={todo.completed}
                  onChange={() => toggleTodo(todo.id)}
                />
                <span>{todo.text}</span>
              </div>
              {/* Кнопка удаления */}
              <button onClick={() => deleteTodo(todo.id)}>{t.delete}</button>
            </li>
          ))
        )}
      </ul>
    </div>
  );
};

export default AdvancedTodoApp;