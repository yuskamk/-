import { useState, useEffect } from 'react';
import { Bar, Line, Doughnut } from 'react-chartjs-2';

const AnalyticsDashboard = () => {
  // Состояния приложения
  const [data, setData] = useState(null); // Данные для графиков
  const [loading, setLoading] = useState(true); // Загружаются ли данные
  const [error, setError] = useState(null); // Ошибка загрузки
  const [dateRange, setDateRange] = useState('week'); // Период: день/неделя/месяц

  // Загружаем данные когда меняется период
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        // Ждем 1 секунду как будто грузим с сервера
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Создаем тестовые данные
        const mockData = generateMockData(dateRange);
        setData(mockData);
      } catch (err) {
        setError('Не удалось загрузить данные');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [dateRange]);

  // Показываем загрузку
  if (loading) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Загружаем данные...</div>;
  }

  // Показываем ошибку
  if (error) {
    return (
      <div style={{ textAlign: 'center', padding: '50px', color: 'red' }}>
        {error}
        <br />
        <button onClick={() => window.location.reload()}>Попробовать снова</button>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px' }}>
      <h1>Аналитический Дашборд</h1>

      {/* Выбор периода */}
      <div style={{ marginBottom: '20px' }}>
        <label>Период: </label>
        {(['day', 'week', 'month']).map(range => (
          <button
            key={range}
            onClick={() => setDateRange(range)}
            style={{
              margin: '0 5px',
              fontWeight: dateRange === range ? 'bold' : 'normal',
            }}
          >
            {range === 'day' ? 'День' : range === 'week' ? 'Неделя' : 'Месяц'}
          </button>
        ))}
      </div>

      {/* Графики */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
        gap: '20px'
      }}>
        {/* График продаж */}
        <div style={{ padding: '15px', border: '1px solid #ccc' }}>
          <Bar data={data.barChart} />
          <div style={{ textAlign: 'center' }}>Продажи по категориям</div>
        </div>

        {/* График трафика */}
        <div style={{ padding: '15px', border: '1px solid #ccc' }}>
          <Line data={data.lineChart} />
          <div style={{ textAlign: 'center' }}>Посетители сайта</div>
        </div>

        {/* Круговой график */}
        <div style={{ padding: '15px', border: '1px solid #ccc' }}>
          <Doughnut data={data.doughnutChart} />
          <div style={{ textAlign: 'center' }}>Устройства пользователей</div>
        </div>
      </div>

      {/* Цифровая статистика */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '15px',
        marginTop: '30px'
      }}>
        <div style={{ textAlign: 'center', padding: '20px', backgroundColor: '#e7f3ff' }}>
          <h3>Общие продажи</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>{data.totalSales}</p>
        </div>
        <div style={{ textAlign: 'center', padding: '20px', backgroundColor: '#fff0e7' }}>
          <h3>Новые пользователи</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>{data.newUsers}</p>
        </div>
      </div>
    </div>
  );
};

// Создаем тестовые данные для графиков
function generateMockData(range) {
  // Подписи для графика в зависимости от периода
  const labels = {
    day: ['9:00', '12:00', '15:00', '18:00', '21:00'],
    week: ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'],
    month: ['Неделя 1', 'Неделя 2', 'Неделя 3', 'Неделя 4']
  }[range];

  return {
    // Данные для столбчатого графика
    barChart: {
      labels,
      datasets: [
        {
          label: 'Товары А',
          data: labels.map(() => Math.floor(Math.random() * 1000)),
          backgroundColor: 'rgba(255, 99, 132, 0.5)',
        }
      ],
    },
    // Данные для линейного графика
    lineChart: {
      labels,
      datasets: [
        {
          label: 'Посетители',
          data: labels.map(() => Math.floor(Math.random() * 500)),
          borderColor: 'rgb(75, 192, 192)',
        }
      ],
    },
    // Данные для кругового графика
    doughnutChart: {
      labels: ['Телефоны', 'Компьютеры', 'Планшеты'],
      datasets: [
        {
          data: [400, 300, 200],
          backgroundColor: ['#ff6384', '#36a2eb', '#ffce56'],
        },
      ],
    },
    totalSales: `$${(Math.random() * 10000).toFixed(2)}`,
    newUsers: Math.floor(Math.random() * 100)
  };
}

export default AnalyticsDashboard;