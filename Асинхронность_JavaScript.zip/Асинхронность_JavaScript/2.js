// Класс для подсчета статистики
class ProcessingStats {
    constructor() {
        this.successful = 0; // Успешные операции
        this.failed = 0;     // Неудачные операции
        this.skipped = 0;    // Пропущенные операции
        this.total = 0;      // Всего операций
    }
    
    addSuccess() {
        this.successful++;
        this.total++;
    }
    
    addFailure() {
        this.failed++;
        this.total++;
    }
    
    addSkip() {
        this.skipped++;
        this.total++;
    }
}

async function processDataAsync(data, processorFn, options = {}) {
    const {
        concurrency = 1,     // Сколько задач выполнять одновременно
        retryAttempts = 0,   // Сколько раз повторять при ошибке
        onProgress = null,   // Функция для отображения прогресса
        shouldPause = () => false // Функция для проверки паузы
    } = options;
    
    const stats = new ProcessingStats();
    const results = [];
    let paused = false;
    
    // Переменные для управления очередью
    let running = 0; // Сколько задач выполняется сейчас
    let currentIndex = 0; // Индекс текущего элемента
    
    // Функция для обработки одного элемента
    async function processItem(item, index) {
        let lastError;
        
        // Пытаемся обработать элемент несколько раз
        for (let attempt = 1; attempt <= retryAttempts + 1; attempt++) {
            // Проверяем, не стоит ли пауза
            if (await shouldPause()) {
                paused = true;
                // Ждем, пока пауза не снимется
                while (paused && await shouldPause()) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }
                paused = false;
            }
            
            try {
                const result = await processorFn(item, index, attempt);
                stats.addSuccess();
                return { index, result, attempts: attempt };
            } catch (error) {
                lastError = error;
                
                // Если это последняя попытка - записываем ошибку
                if (attempt === retryAttempts + 1) {
                    stats.addFailure();
                    return { index, error: lastError, attempts: attempt };
                }
                
                // Ждем перед следующей попыткой
                await new Promise(resolve => setTimeout(resolve, 100 * attempt));
            }
        }
    }
    
    // Функция для запуска следующей задачи
    async function runNext() {
        // Проверяем, можно ли запускать новые задачи
        if (running >= concurrency || currentIndex >= data.length) {
            return;
        }
        
        const index = currentIndex++;
        running++; // Увеличиваем счетчик выполняющихся задач
        
        try {
            const result = await processItem(data[index], index);
            results[index] = result;
            
            // Сообщаем о прогрессе
            if (onProgress) {
                onProgress({
                    processed: results.filter(r => r !== undefined).length,
                    total: data.length,
                    stats: stats
                });
            }
        } finally {
            running--; // Уменьшаем счетчик выполняющихся задач
            runNext(); // Запускаем следующую задачу
        }
    }
    
    // Запускаем первые задачи
    const initialTasks = Math.min(concurrency, data.length);
    for (let i = 0; i < initialTasks; i++) {
        runNext();
    }
    
    // Ждем завершения всех задач
    while (results.length < data.length || running > 0) {
        await new Promise(resolve => setTimeout(resolve, 10));
    }
    
    return {
        results: results,
        stats: stats
    };
}