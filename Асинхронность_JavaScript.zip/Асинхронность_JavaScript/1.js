class AdvancedPromise {
    static retry(promiseFn, maxAttempts = 3, delay = 1000) {
        return new Promise(async (resolve, reject) => {
            let lastError;
            
            // Пытаемся выполнить операцию несколько раз
            for (let attempt = 1; attempt <= maxAttempts; attempt++) {
                try {
                    console.log(`Попытка ${attempt} из ${maxAttempts}`);
                    const result = await promiseFn();
                    resolve(result);
                    return; // Успех - выходим
                } catch (error) {
                    lastError = error;
                    console.log(`Попытка ${attempt} не удалась:`, error.message);
                    
                    // Если это последняя попытка - выходим
                    if (attempt === maxAttempts) break;
                    
                    // Ждем перед следующей попыткой (каждый раз ждем дольше)
                    const currentDelay = delay * Math.pow(2, attempt - 1);
                    console.log(`Ждем ${currentDelay}ms перед следующей попыткой`);
                    await new Promise(resolve => setTimeout(resolve, currentDelay));
                }
            }
            
            // Все попытки закончились неудачей
            reject(lastError);
        });
    }

    static timeout(promise, ms) {
        return new Promise(async (resolve, reject) => {
            // Ставим таймер на отмену
            const timeoutId = setTimeout(() => {
                reject(new Error(`Таймаут: операция не завершена за ${ms}ms`));
            }, ms);
            
            try {
                // Ждем выполнения основного промиса
                const result = await promise;
                clearTimeout(timeoutId); // Убираем таймер
                resolve(result);
            } catch (error) {
                clearTimeout(timeoutId); // Убираем таймер
                reject(error);
            }
        });
    }

    static queue(tasks, concurrency = 1) {
        return new Promise((resolve) => {
            const results = [];
            let running = 0; // Сколько задач выполняется сейчас
            let index = 0; // Какая задача следующая
            let completed = 0; // Сколько задач завершено
            
            function runNext() {
                // Запускаем новые задачи, если есть свободные места
                while (running < concurrency && index < tasks.length) {
                    const currentIndex = index++;
                    running++; // Увеличиваем счетчик выполняющихся задач
                    
                    // Запускаем задачу
                    Promise.resolve(tasks[currentIndex]())
                        .then(result => {
                            // Успех
                            results[currentIndex] = { status: 'fulfilled', value: result };
                        })
                        .catch(error => {
                            // Ошибка
                            results[currentIndex] = { status: 'rejected', reason: error };
                        })
                        .finally(() => {
                            running--; // Уменьшаем счетчик выполняющихся задач
                            completed++; // Увеличиваем счетчик завершенных задач
                            
                            // Если все задачи завершены
                            if (completed === tasks.length) {
                                resolve(results);
                            } else {
                                // Запускаем следующую задачу
                                runNext();
                            }
                        });
                    
                    // Пытаемся запустить еще задачи
                    runNext();
                }
            }
            
            // Начинаем обработку
            runNext();
        });
    }
}