class AsyncPipeline {
    constructor() {
        this.steps = []; // Шаги обработки
    }
    
    // Добавляем шаг в пайплайн
    addStep(stepFn) {
        this.steps.push(stepFn);
        return this; // Возвращаем this для цепочек вызовов
    }
    
    // Выполняем все шаги по порядку
    async execute(input) {
        let result = input;
        
        // Проходим по всем шагам
        for (const step of this.steps) {
            result = await step(result);
            
            // Если шаг вернул undefined - ошибка
            if (result === undefined) {
                throw new Error('Шаг пайплайна вернул undefined');
            }
        }
        
        return result;
    }
    
    // Параллельное выполнение нескольких пайплайнов
    static parallel(pipelines) {
        return {
            execute: async (input) => {
                // Запускаем все пайплайны одновременно
                const results = await Promise.all(
                    pipelines.map(pipeline => pipeline.execute(input))
                );
                return results;
            }
        };
    }
}

// Пример использования
const pipeline = new AsyncPipeline()
    .addStep(async (data) => data.filter(x => x > 0))     // Оставляем только положительные числа
    .addStep(async (data) => data.map(x => x * 2))        // Умножаем все на 2
    .addStep(async (data) => data.reduce((a, b) => a + b, 0)); // Суммируем все числа

// Результат для [-1, 2, -3, 4, 5] будет: (2+4+5) * 2 = 22
const result = await pipeline.execute([-1, 2, -3, 4, 5]);
console.log('Результат:', result);